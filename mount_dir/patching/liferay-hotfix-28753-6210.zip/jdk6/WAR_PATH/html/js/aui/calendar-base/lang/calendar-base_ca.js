YUI.add("lang/calendar-base_ca",function(e){e.Intl.add("calendar-base","ca",{very_short_weekdays:["Dg","Dl","Dt","Dc","Dj","Dv","Ds"],first_weekday:1,weekends:[0,6]})},"patched-v3.11.0");
